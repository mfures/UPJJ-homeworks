package coloring.demo;

import marcupic.opjj.statespace.coloring.FillApp;

public class Bojanje1 {
	public static void main(String[] args) {
		FillApp.run(FillApp.OWL, null); // ili FillApp.ROSE
	}
}
